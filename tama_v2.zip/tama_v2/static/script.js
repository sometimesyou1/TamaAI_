class CodeBotUI {
    constructor() {
        this.sessionId = 'session_' + Date.now();
        this.messages = [];
        this.isTyping = false;
        this.isSidebarOpen = false;
        
        this.initElements();
        this.initEventListeners();
        this.loadTheme();
    }

    initElements() {
        this.elements = {
            sidebar: document.getElementById('sidebar'),
            sidebarToggle: document.getElementById('sidebarToggle'),
            newChatBtn: document.getElementById('newChatBtn'),
            themeToggle: document.getElementById('themeToggle'),
            modelSelector: document.getElementById('modelSelector'),
            messagesContainer: document.getElementById('messagesContainer'),
            welcomeScreen: document.getElementById('welcomeScreen'),
            messagesWrapper: document.getElementById('messagesWrapper'),
            messageInput: document.getElementById('messageInput'),
            sendBtn: document.querySelector('.send-btn'),
            loadingOverlay: document.getElementById('loadingOverlay')
        };
    }

    initEventListeners() {
        // Sidebar toggle
        this.elements.sidebarToggle?.addEventListener('click', () => this.toggleSidebar());
        
        // New chat
        this.elements.newChatBtn?.addEventListener('click', () => this.newChat());
        
        // Theme toggle
        this.elements.themeToggle?.addEventListener('click', () => this.toggleTheme());
        
        // Message input
        this.elements.messageInput?.addEventListener('input', () => this.autoResizeTextarea());
        this.elements.messageInput?.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Send button
        this.elements.sendBtn?.addEventListener('click', () => this.sendMessage());
        
        // Quick actions
        document.querySelectorAll('.quick-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const prompt = btn.dataset.prompt;
                this.elements.messageInput.value = prompt;
                this.sendMessage();
            });
        });

        // Close sidebar on outside click (mobile)
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && 
                !this.elements.sidebar.contains(e.target) && 
                !this.elements.sidebarToggle.contains(e.target)) {
                this.closeSidebar();
            }
        });
    }

    toggleSidebar() {
        this.isSidebarOpen = !this.isSidebarOpen;
        this.elements.sidebar.classList.toggle('active', this.isSidebarOpen);
    }

    closeSidebar() {
        this.isSidebarOpen = false;
        this.elements.sidebar.classList.remove('active');
    }

    loadTheme() {
        const savedTheme = localStorage.getItem('theme') || 'dark';
        document.body.classList.toggle('light-theme', savedTheme === 'light');
        this.updateThemeIcon(savedTheme);
    }

    toggleTheme() {
        const isLight = document.body.classList.contains('light-theme');
        const newTheme = isLight ? 'dark' : 'light';
        
        document.body.classList.toggle('light-theme', newTheme === 'light');
        localStorage.setItem('theme', newTheme);
        this.updateThemeIcon(newTheme);
    }

    updateThemeIcon(theme) {
        const icon = theme === 'light' ? '☀️' : '🌙';
        if (this.elements.themeToggle) {
            this.elements.themeToggle.textContent = icon;
        }
    }

    autoResizeTextarea() {
        const textarea = this.elements.messageInput;
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }

    newChat() {
        this.messages = [];
        this.sessionId = 'session_' + Date.now();
        this.elements.messagesWrapper.innerHTML = '';
        this.elements.welcomeScreen.style.display = 'flex';
        this.closeSidebar();
    }

    async sendMessage() {
        const message = this.elements.messageInput.value.trim();
        if (!message || this.isTyping) return;

        this.hideWelcomeScreen();
        this.addMessage(message, 'user');
        this.elements.messageInput.value = '';
        this.elements.messageInput.style.height = 'auto';
        
        this.showTypingIndicator();
        
        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    session_id: this.sessionId
                })
            });
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            this.hideTypingIndicator();
            this.addMessage(data.message, 'ai', data.usage);
            
        } catch (error) {
            this.hideTypingIndicator();
            this.addMessage(`Sorry, an error occurred: ${error.message}`, 'ai');
        }
    }

    hideWelcomeScreen() {
        this.elements.welcomeScreen.style.display = 'none';
    }

    addMessage(text, sender, usage = null) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        avatarDiv.textContent = sender === 'user' ? '👤' : '🤖';
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const bubbleDiv = document.createElement('div');
        bubbleDiv.className = 'message-bubble';
        
        const textDiv = document.createElement('div');
        textDiv.className = 'message-text';
        
        if (sender === 'ai') {
            let formattedText = text;
            
            // Format code blocks
            formattedText = formattedText.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
                const language = lang || 'text';
                const escapedCode = this.escapeHtml(code.trim());
                return `<pre><code class="language-${language}">${escapedCode}</code><button class="copy-btn" onclick="codeBot.copyCode(this)">Copy</button></pre>`;
            });
            
            // Format inline code
            formattedText = formattedText.replace(/`([^`]+)`/g, '<code>$1</code>');
            
            textDiv.innerHTML = formattedText;
            bubbleDiv.appendChild(textDiv);
            
            if (usage) {
                const usageDiv = document.createElement('div');
                usageDiv.className = 'token-usage';
                usageDiv.textContent = `Tokens: ${usage.prompt_tokens} + ${usage.completion_tokens} = ${usage.total_tokens}`;
                bubbleDiv.appendChild(usageDiv);
            }
            
            // Highlight code
            setTimeout(() => {
                if (typeof Prism !== 'undefined') {
                    Prism.highlightAll();
                }
            }, 0);
        } else {
            textDiv.textContent = text;
            bubbleDiv.appendChild(textDiv);
        }
        
        contentDiv.appendChild(bubbleDiv);
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
        
        this.elements.messagesWrapper.appendChild(messageDiv);
        this.scrollToBottom();
    }

    showTypingIndicator() {
        this.isTyping = true;
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message ai-message';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = `
            <div class="message-avatar">🤖</div>
            <div class="message-content">
                <div class="message-bubble">
                    <div class="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        `;
        this.elements.messagesWrapper.appendChild(typingDiv);
        this.scrollToBottom();
    }

    hideTypingIndicator() {
        this.isTyping = false;
        const typingDiv = document.getElementById('typingIndicator');
        if (typingDiv) {
            typingDiv.remove();
        }
    }

    copyCode(button) {
        const code = button.previousElementSibling.textContent;
        navigator.clipboard.writeText(code).then(() => {
            button.textContent = 'Copied!';
            setTimeout(() => {
                button.textContent = 'Copy';
            }, 2000);
        });
    }

    scrollToBottom() {
        this.elements.messagesWrapper.scrollTop = this.elements.messagesWrapper.scrollHeight;
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the app
const codeBot = new CodeBotUI();

// Add CSS for typing indicator
const style = document.createElement('style');
style.textContent = `
    .typing-indicator {
        display: flex;
        gap: 0.25rem;
    }
    
    .typing-indicator span {
        width: 8px;
        height: 8px;
        background: var(--text-secondary);
        border-radius: 50%;
        animation: typing 1.4s infinite ease-in-out;
    }
    
    .typing-indicator span:nth-child(1) { animation-delay: -0.32s; }
    .typing-indicator span:nth-child(2) { animation-delay: -0.16s; }
    
    @keyframes typing {
        0%, 80%, 100% {
            transform: scale(0.8);
            opacity: 0.5;
        }
        40% {
            transform: scale(1);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);
