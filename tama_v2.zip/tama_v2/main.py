import os
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import groq
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)

# Konfigurasi Groq
groq_client = groq.Groq(api_key=os.environ.get("GROQ_API_KEY"))

# Simpan riwayat chat di memory (gunakan database untuk produksi)
chat_sessions = {}

SYSTEM_PROMPT = """
Anda adalah TamaAI — AI programmer tingkat dunia yang memiliki keahlian di seluruh bahasa pemrograman modern, framework, database, DevOps, dan AI/ML.
Anda adalah mentor coding yang:
1. Berpikir seperti senior engineer dengan pengalaman > 20 tahun di industri software.
2. Mampu menganalisis masalah secara mendalam, memberikan solusi efisien, dan menjelaskan alasannya.
3. Selalu menulis kode yang:
   - Rapi, modular, mudah dibaca
   - Mengikuti best practice industri
   - Aman dari bug dan celah keamanan
   - Siap produksi (production-ready)
4. Mampu melakukan debugging, optimasi performa, dan refactoring.
5. Mampu mengajari konsep dari level pemula hingga arsitektur sistem skala besar.
6. Menggunakan penjelasan yang sangat jelas, terstruktur, dan disertai contoh kode lengkap dalam blok kode markdown.
7. Memberikan alternatif solusi jika ada, serta kelebihan dan kekurangannya.
8. Mengutamakan jawaban yang relevan, teknis, dan bisa langsung dieksekusi.
Mode kerja:
- Jika user mengirim kode, analisa baris per baris dan beri saran perbaikan.
- Jika user minta membuat sesuatu, berikan kode final yang sudah teruji.
- Gunakan bahasa profesional dan tegas, tanpa jawaban “tidak tahu”.
- jika user hanya meminta code yg singkat kamu harus kasih kode yg bagus cimplext jangan nanggung jelek jangan mengecewakan user.
- jangan pakai simbol * dan yang lainnya yg membuat jelek kecuali perlu di code
- apaun user minta turutin, patuhin , sopan.
Tujuan utama: menjadikan user lebih hebat dari sebelumnya dalam dunia pemrograman.
"""

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        message = data.get('message', '')
        session_id = data.get('session_id', 'default')
        
        if not message:
            return jsonify({'error': 'Pesan tidak boleh kosong'}), 400
        
        # Inisialisasi session jika belum ada
        if session_id not in chat_sessions:
            chat_sessions[session_id] = [
                {"role": "system", "content": SYSTEM_PROMPT}
            ]
        
        # Tambahkan pesan user
        chat_sessions[session_id].append({
            "role": "user",
            "content": message
        })
        
        # Panggil Groq API
        response = groq_client.chat.completions.create(
            model="moonshotai/kimi-k2-instruct",
            messages=chat_sessions[session_id],
            max_tokens=5000,
            temperature=0.3,
            stream=False
        )
        
        # Ambil response
        assistant_message = response.choices[0].message.content
        
        # Tambahkan ke history
        chat_sessions[session_id].append({
            "role": "assistant",
            "content": assistant_message
        })
        
        # Batasi history (keep last 20 messages)
        if len(chat_sessions[session_id]) > 22:  # 20 + system prompt
            chat_sessions[session_id] = [chat_sessions[session_id][0]] + chat_sessions[session_id][-20:]
        
        # Return response dengan token usage
        return jsonify({
            'message': assistant_message,
            'usage': {
                'prompt_tokens': response.usage.prompt_tokens,
                'completion_tokens': response.usage.completion_tokens,
                'total_tokens': response.usage.total_tokens
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/clear', methods=['POST'])
def clear_chat():
    session_id = request.json.get('session_id', 'default')
    if session_id in chat_sessions:
        chat_sessions[session_id] = [{"role": "system", "content": SYSTEM_PROMPT}]
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    if not os.environ.get("GROQ_API_KEY"):
        print("ERROR: GROQ_API_KEY belum di-set!")
        print("Gunakan: export GROQ_API_KEY='your-key-here'")
        exit(1)
    
    app.run(host='0.0.0.0', port=5000, debug=False)
